# Sample Business Case Run

This folder is a fully generated dummy-data run of the Business Case Counselor system.

## Case

**Field Service Dispatch and Parts Readiness Modernization**

The sample demonstrates a decision document for approving discovery and pilot design before funding a larger operations/technology modernization effort.

## Dummy inputs included

- `business_case_answers.json` - structured intake answers used by the build command
- `evidence_inbox/field_service_manager_notes.md` - qualitative discovery notes
- `evidence_inbox/baseline_metrics.csv` - dummy current-state metrics
- `evidence_inbox/option_comparison.csv` - dummy option comparison
- `evidence_inbox/risks_assumptions_constraints.csv` - dummy risks, assumptions, and constraints
- `evidence_inbox/pilot_plan.csv` - dummy milestone plan
- `evidence_inbox/stakeholder_interview_extracts.docx` - dummy interview artifact
- `evidence_inbox/dummy_cost_benefit_model.xlsx` - dummy cost-benefit workbook

## Generated outputs

- `outputs/field_service_dispatch_and_parts_readiness_modernization.md`
- `outputs/field_service_dispatch_and_parts_readiness_modernization.docx`
- `outputs/field_service_dispatch_and_parts_readiness_modernization_maturity_review.md`

## Command used

```bash
PYTHONPATH=src python -m business_case_counselor.cli build \
  --answers sample_field_service_case/business_case_answers.json \
  --evidence sample_field_service_case/evidence_inbox \
  --out sample_field_service_case/outputs \
  --docx
```

All financial and operational values are invented for demonstration. Do not treat them as benchmarks.
