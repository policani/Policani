# Field Service Manager Notes

Dummy discovery notes collected for sample-business-case demonstration only.

- Dispatch managers report inconsistent intake across email, ticket forms, and phone requests.
- Common missing data: asset ID, failure symptom, site access constraints, prior repair attempt, urgency rationale, and parts already on hand.
- Planners report that scheduled visits are sometimes released before parts status is confirmed.
- Engineers estimate avoidable triage interruptions of roughly 18 hours per week, mostly to clarify symptoms or site configuration.
- Regional managers want a weekly exception view rather than separate spreadsheet reconciliation.
